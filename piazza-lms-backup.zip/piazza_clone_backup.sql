--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17 (Homebrew)
-- Dumped by pg_dump version 14.17 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: answers; Type: TABLE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE TABLE public.answers (
    id integer NOT NULL,
    content text NOT NULL,
    question_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.answers OWNER TO ahmetcelalgundogdu;

--
-- Name: answers_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE SEQUENCE public.answers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.answers_id_seq OWNER TO ahmetcelalgundogdu;

--
-- Name: answers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER SEQUENCE public.answers_id_seq OWNED BY public.answers.id;


--
-- Name: courses; Type: TABLE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    created_by integer
);


ALTER TABLE public.courses OWNER TO ahmetcelalgundogdu;

--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.courses_id_seq OWNER TO ahmetcelalgundogdu;

--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: questions; Type: TABLE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE TABLE public.questions (
    id integer NOT NULL,
    title character varying NOT NULL,
    content text NOT NULL,
    user_id integer NOT NULL,
    course_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.questions OWNER TO ahmetcelalgundogdu;

--
-- Name: questions_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE SEQUENCE public.questions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_id_seq OWNER TO ahmetcelalgundogdu;

--
-- Name: questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER SEQUENCE public.questions_id_seq OWNED BY public.questions.id;


--
-- Name: simulations; Type: TABLE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE TABLE public.simulations (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    filename text NOT NULL,
    tags text[],
    course_id integer,
    uploaded_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.simulations OWNER TO ahmetcelalgundogdu;

--
-- Name: simulations_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE SEQUENCE public.simulations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.simulations_id_seq OWNER TO ahmetcelalgundogdu;

--
-- Name: simulations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER SEQUENCE public.simulations_id_seq OWNED BY public.simulations.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role text NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['student'::text, 'instructor'::text, 'admin'::text])))
);


ALTER TABLE public.users OWNER TO ahmetcelalgundogdu;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO ahmetcelalgundogdu;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: answers id; Type: DEFAULT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.answers ALTER COLUMN id SET DEFAULT nextval('public.answers_id_seq'::regclass);


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: questions id; Type: DEFAULT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.questions ALTER COLUMN id SET DEFAULT nextval('public.questions_id_seq'::regclass);


--
-- Name: simulations id; Type: DEFAULT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.simulations ALTER COLUMN id SET DEFAULT nextval('public.simulations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: answers; Type: TABLE DATA; Schema: public; Owner: ahmetcelalgundogdu
--

COPY public.answers (id, content, question_id, user_id, created_at) FROM stdin;
3	Bu bir test cevabıdır.	1	2	2025-03-26 21:38:30.694113+03
4	Moleküller çarpıştığı için basınç oluşur.	1	2	2025-03-26 21:40:33.999017+03
2	Bu içerik güncellendi.	1	2	2025-03-26 21:37:11.568899+03
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: ahmetcelalgundogdu
--

COPY public.courses (id, title, description, created_by) FROM stdin;
1	Fizik 130	Mekanik, ısı ve kinetik teori konuları.	1
2	Fizik 150	Liq mech	1
3	Fizik 150	Liq mech	1
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: ahmetcelalgundogdu
--

COPY public.questions (id, title, content, user_id, course_id, created_at) FROM stdin;
1	Gazlar neden basınç oluşturur?	Moleküllerin çarpışması ile mi alakalı?	1	1	2025-03-26 18:01:28.28896+03
2	Gazlar neden basınç oluşturur?	Moleküllerin çarpışması ile mi alakalı?	1	1	2025-03-26 18:01:51.98355+03
3	Gazlar neden basınç oluşturur?	Moleküllerin çarpışması ile mi alakalı?	1	1	2025-03-26 18:06:15.128568+03
4	Gazlar neden basınç oluşturur?	Moleküllerin çarpışması ile mi alakalı?	1	1	2025-03-26 18:06:17.688125+03
\.


--
-- Data for Name: simulations; Type: TABLE DATA; Schema: public; Owner: ahmetcelalgundogdu
--

COPY public.simulations (id, title, description, filename, tags, course_id, uploaded_by, created_at) FROM stdin;
1	Gaz Molekülleri Simülasyonu	Gazların sıcaklığa göre hareketlerini gözlemleyebileceğiniz etkileşimli bir Unity oyunu.	gaz_simulasyonu.exe	{kinetik,ısı,fizik130}	1	1	2025-03-26 15:55:03.281623
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ahmetcelalgundogdu
--

COPY public.users (id, name, email, password_hash, role) FROM stdin;
1	Ahmet Öğretmen	ahmet@lms.com	hashed_password_ahmet	instructor
2	Elif Yılmaz	elif@lms.com	hashed_password_elif	student
3	Mehmet Demir	mehmet@lms.com	hashed_password_mehmet	student
4	Test Öğrenci	test@lms.com	test1234	student
8	Test Öğrenci	test123@lms.com	test1234	student
9	Ahmethan Gülbahar	ahmethangülbahar@lms.com	Ahmet123	student
10	Top Toplayıcı	toptoplayıcı@lms.com	toptoplayıcı	student
\.


--
-- Name: answers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmetcelalgundogdu
--

SELECT pg_catalog.setval('public.answers_id_seq', 4, true);


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmetcelalgundogdu
--

SELECT pg_catalog.setval('public.courses_id_seq', 3, true);


--
-- Name: questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmetcelalgundogdu
--

SELECT pg_catalog.setval('public.questions_id_seq', 4, true);


--
-- Name: simulations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmetcelalgundogdu
--

SELECT pg_catalog.setval('public.simulations_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmetcelalgundogdu
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- Name: answers answers_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.answers
    ADD CONSTRAINT answers_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: simulations simulations_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.simulations
    ADD CONSTRAINT simulations_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_answers_id; Type: INDEX; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE INDEX ix_answers_id ON public.answers USING btree (id);


--
-- Name: ix_questions_id; Type: INDEX; Schema: public; Owner: ahmetcelalgundogdu
--

CREATE INDEX ix_questions_id ON public.questions USING btree (id);


--
-- Name: answers answers_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.answers
    ADD CONSTRAINT answers_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id);


--
-- Name: answers answers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.answers
    ADD CONSTRAINT answers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: courses courses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: questions questions_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: questions questions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: simulations simulations_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.simulations
    ADD CONSTRAINT simulations_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: simulations simulations_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmetcelalgundogdu
--

ALTER TABLE ONLY public.simulations
    ADD CONSTRAINT simulations_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

